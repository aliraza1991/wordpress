<?php
/*
Plugin Name: twotwentyfive metaboxes
Plugin URI:
Description: Adding Metaboxes for twotwentyfive
Version: 1.0.0
Author: Ali Raza
Author URI: https://www.indiamart.com/razapurse/
License: GNU General Public License v2 or later
Text Domain: twotwentyfive-metaboxes
Domain Path: /languages
*/


if(!defined('WPINC')){
    die;
}

include_once('includes/metaboxes.php');
include_once('includes/enqueue-assets.php');
